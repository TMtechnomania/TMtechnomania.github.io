// Shared constants for the extension
export const WALLPAPER_JSON_URL =
	"https://buildwithkt.dev/extensions/themes+/assets/wallpaper.json";

// IndexedDB Config
// The schema version is an explicit constant in db.js (not derived from the
// extension version) so downgrades cannot trigger VersionError/data loss.
export const IDB_NAME = "themes-assets";
export const IDB_STORE_THUMBS = "thumbs"; // Store for thumbnails
export const IDB_STORE_MEDIA = "media"; // Store for full media assets
export const IDB_STORE_WALLPAPERS = "wallpapers"; // Store for user uploaded wallpapers

// Chrome Storage Keys
export const STORAGE_KEY_DB = "wallpaperDB"; // Key for the manifest JSON
export const STORAGE_KEY_SETTINGS = "userSettings"; // For user settings
// Slideshow cursor, deliberately kept outside userSettings: every new tab
// advances it, and it must never race with (or broadcast) real setting edits.
export const STORAGE_KEY_WALLPAPER_ROTATION = "wallpaperRotation";

// Default settings
export const DEFAULT_CONFIG = {
	uiScale: 1, // Multiplier: 0.8, 1, 1.2
	wallpaper: {
		type: "img", //mono, img, vdo
		collection: "predefined",
		mode: "random",
		specific: null,
		last_id: "img-001",

		// Independent settings per type
		imgSettings: {
			collection: "predefined",
			mode: "random",
			specific: null,
		},
		videoSettings: {
			collection: "predefined",
			mode: "random",
			specific: null,
			muted: true, // Default muted
		},
		matrixSettings: {
			color: "#00ff00",
			speed: 50,
			fontSize: 16,
		},
		filters: {
			blur: 0,
			brightness: 100,
			contrast: 100,
			saturate: 100,
			grayscale: 0,
			sepia: 0,
			invert: 0,
			sharpness: 0,
		},
		duotoneSettings: {
			theme: "sunset",
			customColors: ["#ff7e5f", "#feb47b"],
			direction: "135deg",
			matchTheme: false,
		},

		blur: 0, // in pixels
		brightness: 100, // in percentage
		contrast: 100, // in percentage
		grayscale: 0, // in percentage
		saturate: 100, // in percentage
		sharpness: 0, // 0-100, SVG unsharp mask
		muted: true, // Default to muted for video wallpapers
		rain: false, // Rain customization
		rainSettings: {
			count: 150,
			speed: 15,
			length: 20,
			color: "#ffffff",
			opacity: 20,
		},
	},
	searchbar: {
		enabled: true,
		engine: "default", // 'default' means browser default search engine using browser.search API, google, bing, duckduckgo, youtube, reddit, quora, stackoverflow, spotify are other options
		voice_search: true,
		vertical_align: "center", // 'top', 'center', 'bottom'
		horizontal_align: "center", // 'left', 'center', 'right'
		target: "self", // 'self' for same tab, 'blank' for new tab
	},
	actionbar: {
		autohide: false, // Auto-hide the action bar by setting the initial bottom position to -50%.
		clock: {
			enabled: true,
			format: "12", // '12' or '24'
		},
		date: {
			enabled: false,
		},
		alarm: {
			enabled: false, // Show upcoming alarm
		},
		weather: {
			enabled: false,
			apiKey: "",
			city: "", // Optional override
			units: "metric", // metric (Celsius) or imperial (Fahrenheit)
			showHumidity: false,
			showWind: false,
			showFeelsLike: false,
		},
		display_style: "centralised", // 'centralised' or 'spread'
		shortcuts: {
			enabled: true,
		},
		famcam: {
			enabled: true,
			snapAction: "camera", // 'camera' | 'screenshot'
			flash: {
				tone: "warm", // 'cool', 'warm', 'neutral', 'custom'
				customColor: "#ffffff",
				type: "ring-circle", // 'fullscreen', 'ring-wide', 'ring-circle'
				borderWidth: 2, // 1-8
				brightness: 100, // 5-100
			},
		},
	},
	onScreenClock: {
		enabled: false,
		font: "default",
		color: "default",
		customColor: null,
		showSeconds: false,
		outline: false,
		outlineColor: null,
	},
	greeting: {
		enabled: false,
		outline: false,
		type: "default", // 'default' | 'custom'
		customName: "",
		customText: "",
	},
	// Font settings: default to Google Outfit
	font: {
		family: "Outfit",
		// Default import URL for Outfit with common weights
		importUrl:
			"https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;700;800&display=swap",
	},
	theme: "system",
};

export const DUOTONE_THEMES = {
	sunset: {
		name: "Sunset",
		colors: ["#ff7e5f", "#feb47b"],
		direction: "135deg",
		ui: {
			base: "#2d1b1e",
			off: "#4a2c31",
			accent: "#ff7e5f",
		},
	},
	ocean: {
		name: "Ocean",
		colors: ["#2193b0", "#6dd5ed"],
		direction: "135deg",
		ui: {
			base: "#0d1b2a",
			off: "#1b263b",
			accent: "#6dd5ed",
		},
	},
	forest: {
		name: "Forest",
		colors: ["#11998e", "#38ef7d"],
		direction: "135deg",
		ui: {
			base: "#0e1c15",
			off: "#1b3a2a",
			accent: "#38ef7d",
		},
	},
	berry: {
		name: "Berry",
		colors: ["#c31432", "#240b36"],
		direction: "135deg",
		ui: {
			base: "#1a0b14",
			off: "#2d1222",
			accent: "#c31432",
		},
	},
	night: {
		name: "Night",
		colors: ["#000428", "#004e92"],
		direction: "135deg",
		ui: {
			base: "#000428",
			off: "#001242",
			accent: "#00d2ff",
		},
	},
};

export const DEFAULT_SHORTCUTS = [
	{
		id: "s_chrome",
		title: "Chrome Web Store",
		url: "https://chrome.google.com/webstore",
		icon: "assets/svgs-fontawesome/brands/chrome.svg",
		builtin: true,
	},
	{
		id: "s_youtube",
		title: "YouTube",
		url: "https://www.youtube.com",
		icon: "assets/svgs-fontawesome/brands/youtube.svg",
		builtin: true,
	},
	{
		id: "s_dribbble",
		title: "Dribbble",
		url: "https://dribbble.com",
		icon: "assets/svgs-fontawesome/brands/dribbble.svg",
		builtin: true,
	},
	{
		id: "s_mdn",
		title: "MDN Web Docs",
		url: "https://developer.mozilla.org",
		icon: "assets/svgs-fontawesome/brands/firefox-browser.svg",
		builtin: true,
	},
];

export const DEFAULT_SHORTCUT_ICON_FALLBACK =
	"assets/svgs-fontawesome/solid/globe.svg";

const IMAGE_COLOR_STYLE_ID = "theme-image-color-style";

let _glassSchemeMedia = null;
let _glassSchemeHandler = null;

function clearGlassSchemeListener() {
	if (_glassSchemeMedia && _glassSchemeHandler) {
		try {
			if (_glassSchemeMedia.removeEventListener) {
				_glassSchemeMedia.removeEventListener(
					"change",
					_glassSchemeHandler,
				);
			} else if (_glassSchemeMedia.removeListener) {
				_glassSchemeMedia.removeListener(_glassSchemeHandler);
			}
		} catch (e) {}
	}
	_glassSchemeMedia = null;
	_glassSchemeHandler = null;
}

function applyGlassScheme() {
	if (!_glassSchemeMedia) return;
	document.documentElement.setAttribute(
		"data-glass",
		_glassSchemeMedia.matches ? "dark" : "light",
	);
}

function updateImageColorStyle() {
	let styleTag = document.getElementById(IMAGE_COLOR_STYLE_ID);
	if (!styleTag) {
		styleTag = document.createElement("style");
		styleTag.id = IMAGE_COLOR_STYLE_ID;
		document.head.appendChild(styleTag);
	}
	styleTag.textContent = "img { color: var(--text-base); }";
}

export function applyTheme(theme) {
	const root = document.documentElement;
	clearGlassSchemeListener();
	root.removeAttribute("data-glass");

	if (theme === "glass-system") {
		// Follow the OS light/dark preference and update live if it changes.
		root.setAttribute("data-theme", "glass");
		_glassSchemeMedia = window.matchMedia(
			"(prefers-color-scheme: dark)",
		);
		_glassSchemeHandler = applyGlassScheme;
		applyGlassScheme();
		try {
			if (_glassSchemeMedia.addEventListener) {
				_glassSchemeMedia.addEventListener(
					"change",
					_glassSchemeHandler,
				);
			} else if (_glassSchemeMedia.addListener) {
				_glassSchemeMedia.addListener(_glassSchemeHandler);
			}
		} catch (e) {}
	} else if (theme === "glass-light" || theme === "glass-dark") {
		root.setAttribute("data-theme", "glass");
		root.setAttribute(
			"data-glass",
			theme === "glass-dark" ? "dark" : "light",
		);
	} else if (theme === "system" || !theme) {
		root.removeAttribute("data-theme");
	} else {
		root.setAttribute("data-theme", theme);
	}

	updateImageColorStyle();
}

/**
 * Apply the user's UI size preference.
 *
 * `--ui-scale` is a pure multiplier on the fluid root font-size (see
 * css/base.css): the automatic per-screen scaling is handled by the vmin
 * clamp, so this only expresses Small / Normal / Large. Setting it to 1
 * leaves the responsive sizing untouched.
 */
export function applyUiScale(scale) {
	const value = Number(scale);
	const safe =
		Number.isFinite(value) && value > 0 ? Math.min(Math.max(value, 0.5), 2) : 1;
	document.documentElement.style.setProperty("--ui-scale", String(safe));
}
