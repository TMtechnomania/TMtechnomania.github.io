import {
	getMediaEntry,
	getUserWallpaperList,
	getUserWallpaperById,
	getAvailableMediaKeys,
} from "./db.js";
import { DUOTONE_THEMES, DEFAULT_CONFIG } from "./config.js";
import { resolveAssetUrl } from "./api.js";
import { toggleRain } from "./rainEffect.js";
import { startMatrix, stopMatrix } from "./matrixEffect.js";

let lastObjectUrl = null;
let lastThumbUrl = null;

function clearPreviousWallpaper() {
	stopMatrix(); // Stop Matrix if running

	if (lastObjectUrl) {
		try {
			URL.revokeObjectURL(lastObjectUrl);
		} catch (e) {}
		lastObjectUrl = null;
	}
	if (lastThumbUrl) {
		try {
			URL.revokeObjectURL(lastThumbUrl);
		} catch (e) {}
		lastThumbUrl = null;
	}
	// Always clear media session when removing wallpaper to free keys
	if ("mediaSession" in navigator) {
		[
			"play",
			"pause",
			"stop",
			"seekbackward",
			"seekforward",
			"previoustrack",
			"nexttrack",
		].forEach((action) => {
			try {
				navigator.mediaSession.setActionHandler(action, null);
			} catch (e) {}
		});
	}
	const prev = document.getElementById("wallpaper");
	if (prev) {
		prev.remove();
	}
}
function setWallpaperElement(type, url, styleCfg = {}, thumbUrl = null) {
	clearPreviousWallpaper();
	const el = document.createElement(type === "img" ? "img" : "video");
	el.id = "wallpaper";
	el.src = url;
	if (type === "video") {
		el.autoplay = true;
		el.loop = true;
		el.controls = false; // Explicitly disable controls
		el.preload = "auto"; // Optimize loading

		// Default to true if undefined to be safe, or respect config
		el.muted = styleCfg.muted !== false;
		el.playsInline = true;
		el.disablePictureInPicture = true; // Prevent PiP button

		if (thumbUrl) {
			el.poster = thumbUrl;
		}
		// Handle autoplay failures (browser policy)
		el.addEventListener(
			"canplay",
			() => {
				el.play().catch((err) => {
					console.warn(
						"[Wallpaper] Video autoplay blocked:",
						err.message,
					);
				});
			},
			{ once: true },
		);
		// Handle video stall/error
		el.addEventListener("error", (e) => {
			const error = el.error;
			console.error(
				"[Wallpaper] Video load error:",
				error ? `${error.code}: ${error.message}` : "Unknown error",
			);
			el.remove();
		});

		// FIX: Disable remote playback and user control
		el.disableRemotePlayback = true;
		el.style.pointerEvents = "none";
		el.tabIndex = -1;

		// Attempt to block media keys for this video ONLY if NOT muted
		// If muted, we should let keys pass through to other apps
		if (!el.muted && "mediaSession" in navigator) {
			const noop = () => {};
			[
				"play",
				"pause",
				"stop",
				"seekbackward",
				"seekforward",
				"previoustrack",
				"nexttrack",
			].forEach((action) => {
				try {
					navigator.mediaSession.setActionHandler(action, noop);
				} catch (e) {}
			});
		}
	} else {
		el.onerror = () => {
			console.error("[Wallpaper] Image load error for:", url);
			el.remove();
		};
	}
	document.body.appendChild(el);
	try {
		const normalizedStyle = normalizeWallpaperConfig(styleCfg || {});
		applyStyleConfigToElement(el, normalizedStyle);
	} catch (e) {}
}

// Global Visibility Listener for Video Wallpaper
document.addEventListener("visibilitychange", () => {
	const el = document.getElementById("wallpaper");
	if (el && el.tagName === "VIDEO") {
		if (document.hidden) {
			el.pause();
		} else {
			// Only play if it was supposed to be playing?
			// For wallpaper, we always assume it should be playing if visible.
			el.play().catch(() => {});
		}
	}
});

function setWallpaperFromBlob(type, blob, styleCfg = {}, thumbBlob = null) {
	const url = URL.createObjectURL(blob);
	let thumbUrl = null;
	if (thumbBlob) {
		thumbUrl = URL.createObjectURL(thumbBlob);
	}
	setWallpaperElement(type, url, styleCfg, thumbUrl);
	lastObjectUrl = url;
	if (thumbUrl) {
		lastThumbUrl = thumbUrl;
	}
}
// Cache of downloaded media keys
let _downloadedMediaKeys = null;

export function clearMediaKeysCache() {
	_downloadedMediaKeys = null;
}

async function getDownloadedMediaKeysSet() {
	if (_downloadedMediaKeys && _downloadedMediaKeys.size > 0)
		return _downloadedMediaKeys;

	try {
		// First attempt
		let keys = await getAvailableMediaKeys();

		// If keys is null, it means IDB is completely unavailable (per our db.js logic)
		// Return null to signal "don't filter"
		if (keys === null) {
			return null;
		}

		// If empty array, wait and retry once (handling fresh install race condition)
		if (keys.length === 0) {
			await new Promise((r) => setTimeout(r, 1000));
			keys = await getAvailableMediaKeys();
			if (keys === null) return null; // IDB died during retry
		}

		_downloadedMediaKeys = new Set(keys || []);
	} catch (e) {
		// If error, return null so we don't filter out everything
		console.warn("Error fetching media keys, disabling filter:", e);
		return null;
	}
	return _downloadedMediaKeys;
}

async function filterEntriesWithMedia(list) {
	if (!Array.isArray(list) || list.length === 0) return [];
	const downloadedSet = await getDownloadedMediaKeysSet();

	// If set is null, IDB is down -> return everything (allow network load)
	if (!downloadedSet) return list;

	return list.filter((entry) => downloadedSet.has(`${entry.id}::media`));
}
async function chooseEntry(manifest, config, excludeId = null) {
	let list = [];
	let effectiveMode = config.mode;

	// Get the wallpaper list based on collection
	if (config.collection === "user") {
		const userWalls = await getUserWallpaperList();
		// Filter by type - explicit check for both types
		const targetType =
			config.type === "img" ? "img"
			: config.type === "video" ? "video"
			: null;
		if (targetType) {
			list = userWalls.filter((w) => w.type === targetType);
		} else {
			list = []; // Invalid type, no user wallpapers
		}

		// If no user wallpapers of this type, fall back to predefined
		if (list.length === 0) {
			const type = config.type === "img" ? "images" : "videos";
			list = manifest[type] || [];
			// Filter for downloaded predefined
			list = await filterEntriesWithMedia(list);
			// If was specific mode, switch to random
			if (effectiveMode === "specific") {
				effectiveMode = "random";
			}
		}
	} else {
		// Predefined collection - filter for downloaded
		const type = config.type === "img" ? "images" : "videos";
		const all = manifest[type] || [];
		list = await filterEntriesWithMedia(all);
	}

	if (!list.length) return null;

	let available = list.slice();

	if (excludeId) {
		available = available.filter((e) => e.id !== excludeId);
		if (available.length === 0) {
			available = list.slice();
		}
	}

	if (effectiveMode === "specific" && config.specific) {
		const found = available.find((e) => e.id === config.specific);
		if (found) return found;
		// Specific not found, fall back to random
	}

	if (effectiveMode === "sequence" && config.last_id) {
		const lastIdx = available.findIndex((e) => e.id === config.last_id);
		const nextIdx = lastIdx < 0 ? 0 : (lastIdx + 1) % available.length;
		return available[nextIdx];
	}

	// Random mode or fallback
	return available[Math.floor(Math.random() * available.length)];
}

async function tryLoadFromBlob(entry, type, styleCfg = {}) {
	const id = typeof entry === "string" ? entry : entry?.id;

	// User Wallpaper - fetch single entry by ID instead of loading all
	if (String(id).startsWith("user-wall-")) {
		const found = await getUserWallpaperById(id);
		if (found && found.blob) {
			setWallpaperFromBlob(type, found.blob, styleCfg, found.thumbBlob);
			return true;
		}
		return false;
	}

	// Predefined wallpaper — try IDB first
	const mediaKey = `${id}::media`;
	const mediaEntry = await getMediaEntry(mediaKey).catch(() => null);
	if (mediaEntry && mediaEntry.status === "ok" && mediaEntry.blob) {
		let thumbBlob = null;
		if (type === "video") {
			const thumbKey = `${id}::thumb`;
			const thumbEntry = await getMediaEntry(thumbKey).catch(() => null);
			if (thumbEntry && thumbEntry.status === "ok" && thumbEntry.blob) {
				thumbBlob = thumbEntry.blob;
			}
		}
		setWallpaperFromBlob(type, mediaEntry.blob, styleCfg, thumbBlob);
		return true;
	}

	// Fallback: load directly from network URL
	if (typeof entry === "object" && entry?.asset) {
		const assetUrl = resolveAssetUrl(entry.asset);
		if (assetUrl) {
			const thumbUrl = entry.thumb ? resolveAssetUrl(entry.thumb) : null;
			setWallpaperElement(type, assetUrl, styleCfg, thumbUrl);
			return true;
		}
	}

	return false;
}

export async function renderWallpaper(config, manifest) {
	const cfg = normalizeWallpaperConfig(config || {});
	console.log("[Wallpaper] Rendering with config:", cfg);

	// Apply Rain Effect
	toggleRain(cfg.rain);

	// Clean up previous Duotone styles
	document.documentElement.style.removeProperty("--color-base");
	document.documentElement.style.removeProperty("--color-off");
	document.documentElement.style.removeProperty("--color-accent");
	document.documentElement.style.removeProperty("--text-accent");

	// Handle Matrix Mode
	if (cfg.type === "matrix") {
		clearPreviousWallpaper();
		document.body.style.backgroundImage = "";
		document.body.style.backgroundColor = "black";

		// Use config settings or defaults
		const mSettings =
			cfg.matrixSettings || DEFAULT_CONFIG.wallpaper.matrixSettings;
		startMatrix(mSettings);
		return null;
	}

	// Handle Mono Mode
	if (cfg.type === "mono") {
		clearPreviousWallpaper();
		document.body.style.backgroundImage = "";
		document.body.style.backgroundColor = "var(--color-off)";
		return null;
	}

	// Handle Duotone Mode
	if (cfg.type === "duotone") {
		clearPreviousWallpaper();
		// Use defaults if missing
		const dSettings =
			cfg.duotoneSettings || DEFAULT_CONFIG.wallpaper.duotoneSettings;
		const themeName = dSettings.theme || "sunset";
		let colors = [];
		let direction = "135deg";

		if (themeName === "custom") {
			colors =
				dSettings.customColors ||
				DEFAULT_CONFIG.wallpaper.duotoneSettings.customColors;
			direction = dSettings.direction || "135deg";
		} else {
			const theme = DUOTONE_THEMES[themeName] || DUOTONE_THEMES.sunset;
			colors = theme.colors;
			direction = theme.direction;
		}

		const gradient = `linear-gradient(${direction}, ${colors[0]}, ${colors[1]})`;
		document.body.style.backgroundColor = "";
		document.body.style.backgroundImage = gradient;
		document.body.style.backgroundAttachment = "fixed";
		document.body.style.backgroundSize = "cover";

		// Apply UI Theme
		let uiColors = null;
		if (themeName === "custom") {
			// Convert array to object
			if (
				dSettings.customUiColors &&
				dSettings.customUiColors.length === 3
			) {
				uiColors = {
					base: dSettings.customUiColors[0],
					off: dSettings.customUiColors[1],
					accent: dSettings.customUiColors[2],
				};
			}
		} else {
			const theme = DUOTONE_THEMES[themeName] || DUOTONE_THEMES.sunset;
			uiColors = theme.ui;
		}

		if (dSettings.matchTheme && uiColors) {
			document.documentElement.style.setProperty(
				"--color-base",
				uiColors.base,
			);
			document.documentElement.style.setProperty(
				"--color-off",
				uiColors.off,
			);
			document.documentElement.style.setProperty(
				"--color-accent",
				uiColors.accent,
			);
			// Also sync text-accent
			document.documentElement.style.setProperty(
				"--text-accent",
				uiColors.accent,
			);
			document.documentElement.style.setProperty(
				"--text-accent",
				uiColors.accent,
			);
		} else {
			// Ensure cleanup if toggled off
			// Already cleaned at top, no op needed unless we want to be paranoid?
			// Actually, if we just set them above, we don't need to unset them here because we unset them at the very start.
			// But wait, if matchTheme is FALSE, we just want standard variables.
			// The top-level cleanup ensures we start clean.
			// So "else" block is empty or unnecessary.
		}

		return null;
	}

	// Reset specific styles for other modes
	document.body.style.backgroundColor = "";
	document.body.style.backgroundImage = "";
	// Reset specific styles for other modes
	document.body.style.backgroundColor = "";
	document.body.style.backgroundImage = "";

	// Vars already reset at top

	// Get entry (chooseEntry handles all fallback logic)
	const excludeId = cfg.mode === "random" && cfg.last_id ? cfg.last_id : null;
	let entry = await chooseEntry(manifest, cfg, excludeId);

	if (!entry) {
		// Should not happen if predefined wallpapers exist
		// console.warn('No wallpaper entry found');
		return null;
	}

	// Load the wallpaper
	const success = await tryLoadFromBlob(entry, cfg.type, cfg);
	if (success) {
		return entry.id;
	}

	// First entry failed - try another
	let retryEntry = await chooseEntry(manifest, cfg, entry.id);
	if (retryEntry) {
		const retrySuccess = await tryLoadFromBlob(retryEntry, cfg.type, cfg);
		if (retrySuccess) {
			return retryEntry.id;
		}
	}

	// Should not reach here if predefined wallpapers exist and are downloaded
	// console.warn('Failed to load any wallpaper');
	return null;
}
function normalizeStyleValue(prop, v) {
	if (v == null) return null;
	if (typeof v === "string") {
		const trimmed = v.trim();
		if (
			/^[0-9.]+%$/.test(trimmed) ||
			/^[0-9.]+(px|em|rem|vh|vw)$/.test(trimmed)
		)
			return trimmed;
		const num = Number(trimmed);
		if (!Number.isNaN(num)) v = num;
		else return trimmed;
	}
	if (typeof v === "number") {
		if (prop === "blur") return `${v}px`;
		if (
			prop === "brightness" ||
			prop === "contrast" ||
			prop === "grayscale"
		) {
			if (v > 10) return `${v}%`;
			return String(v);
		}
		return String(v);
	}
	return null;
}
function buildFilterString(styleCfg = {}) {
	const parts = [];
	const isZero = (val) =>
		typeof val === "string" &&
		/^0(?:\.0+)?(?:px|%|em|rem|vh|vw)?$/.test(val);
	const isHundred = (val) =>
		typeof val === "string" && /^100(?:\.0+)?(?:%|)?$/.test(val);
	const rawBlur = styleCfg.blur;
	const b = normalizeStyleValue("blur", rawBlur);
	if (b && !isZero(b)) parts.push(`blur(${b})`);
	const brightness = normalizeStyleValue("brightness", styleCfg.brightness);
	if (brightness && !isHundred(brightness))
		parts.push(`brightness(${brightness})`);
	const contrast = normalizeStyleValue("contrast", styleCfg.contrast);
	if (contrast && !isHundred(contrast)) parts.push(`contrast(${contrast})`);
	const grayscale = normalizeStyleValue("grayscale", styleCfg.grayscale);
	if (grayscale && !isZero(grayscale)) parts.push(`grayscale(${grayscale})`);
	const filterStr = parts.join(" ");
	try {
		if (filterStr) {
		} else if (
			styleCfg.blur !== 0 ||
			styleCfg.brightness !== 100 ||
			styleCfg.contrast !== 100 ||
			styleCfg.grayscale !== 0
		) {
		}
	} catch (e) {}
	return filterStr;
}
function applyStyleConfigToElement(el, styleCfg = {}) {
	if (!el || !styleCfg) return;
	try {
	} catch (e) {}
	const filter = buildFilterString(styleCfg);
	if (filter) el.style.filter = filter;
	if (styleCfg.position) el.style.objectPosition = String(styleCfg.position);
	if (styleCfg.scale != null) {
		let s = styleCfg.scale;
		if (typeof s === "number") s = String(s);
		if (typeof s === "string" && s.endsWith("%")) {
			const n = Number(s.replace("%", "")) / 100;
			el.style.transform = `scale(${n})`;
		} else {
			el.style.transform = `scale(${s})`;
		}
	}
}
function normalizeWallpaperConfig(cfg = {}) {
	if (!cfg || typeof cfg !== "object") return {};
	const src =
		cfg.wallpaper && typeof cfg.wallpaper === "object" ?
			cfg.wallpaper
		:	cfg;
	const out = {
		type: src.type ?? "img",
		mode: src.mode ?? "random",
		collection: src.collection ?? "predefined",
		specific: src.specific ?? null,
		last_id: src.last_id ?? null,
		blur: src.blur ?? 0,
		brightness: src.brightness ?? 100,
		contrast: src.contrast ?? 100,
		grayscale: src.grayscale ?? 0,
		position: src.position ?? src.objectPosition ?? undefined,
		scale: src.scale ?? undefined,
		muted: src.muted !== false, // Default true
		rain: src.rain ?? false,
		duotoneSettings: src.duotoneSettings ?? undefined,
		matrixSettings: src.matrixSettings ?? undefined,
	};
	return out;
}
