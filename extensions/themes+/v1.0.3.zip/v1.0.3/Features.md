1. Search (text + voice).
2. Advance search by using the site name and content (upto 8 for lvl 1)
3. Wallpapers and Video BGs (predefined and custom) (random, sequence and specific) (BG blur)
4. Screen saver option to avoid color burns on various displays (5, 10, 15min, never options)
5. Checkbox based tasks from momentum
6. Notes (static and Flaoting).
7. Quotes
8. Timer
9. Tabs management panel with direct switch, close or pin
10. workspace - group of links that can be launched together and managed with ease
11. Bookmarks management - create, edit, delete, folder
12. Pomodoro mode - more research required.
13. Theme - Opaque and Glass

https://www.streamlinehq.com/icons/core-flat-free  #0072FF #ABD0FF

https://www.streamlinehq.com/icons/material-symbols-outlined-line


1. Productivity & Work
Google Docs (document editing)
Microsoft Office 365 (online suite)
Notion (note-taking and project management)
Trello (task management)
Slack (team communication)
2. Social & Communication
Facebook (social networking)
Twitter/X (microblogging)
Instagram (photo/video sharing)
LinkedIn (professional networking)
WhatsApp Web (messaging)
3. Entertainment & Media
YouTube (video streaming)
Netflix (movies/TV)
Spotify (music streaming)
Twitch (live streaming)
Reddit (forums and discussions)
4. News & Information
Google News (aggregated news)
BBC News (global news)
CNN (news and analysis)
Wikipedia (encyclopedia)
The New York Times (journalism)
5. Shopping & Finance
Amazon (e-commerce)
eBay (auctions and sales)
PayPal (payments)
Etsy (handmade goods)
Walmart (retail)
6. Development & Tech
GitHub (code repositories)
Stack Overflow (Q&A for developers)
MDN Web Docs (web development docs)
CodePen (code playground)
Figma (design tool)
7. Gaming
Steam (PC game store and launcher)
Epic Games Store (free games and store)
GOG (DRM-free games)
Ubisoft Store (Ubisoft game purchases)
EA Origin/EA App (EA games and store)
8. Utilities & Tools (Kept as 7th, but if you want to drop one category, this could be optional)
Google Maps (navigation)
Gmail (email)
Google Drive (file storage)
Dropbox (cloud storage)
Translate.google.com (language translation)
Additional Notes
Gaming Focus: I prioritized major, cross-platform stores that are popular and accessible. If you want to include console-specific ones (e.g., PlayStation Store, Xbox, Nintendo), let me know for swaps.
Total Reduction: Dropped to 5 per category as requested, removing one from each (e.g., Zoom from Productivity, Discord from Social, etc.) to streamline.
Implementation: This list can be stored in a new file like websites.js as an array of categories with site objects (name, URL, icon). For the popup, use a grid layout with categories as headers.
User Customization: In the future settings panel, allow users to enable/disable categories or add custom sites.