import { loadCSS, unloadCSS } from "./cssLoader.js";
import { renderBrandIcon, renderInlineIcon } from "./brandIconLoader.js";

let _tabsRibbonListeners = null;
let _tabsToggleElement = null;
let _tabsRibbonAutoCloseTimer = null;
const TABS_RIBBON_AUTO_CLOSE_MS = 30000;

export function setTabsToggleElement(el) {
	_tabsToggleElement = el;
}

export async function toggleTabsRibbon() {
	let ribbon = document.getElementById("tabs-ribbon");
	if (ribbon) {
		_clearTabsRibbonAutoCloseTimer();
		document.body.removeChild(ribbon);
		detachTabsListeners();
		if (_tabsToggleElement) {
			_tabsToggleElement.classList.remove("active");
			try {
				_tabsToggleElement.setAttribute("aria-expanded", "false");
			} catch (e) {}
		}
		unloadCSS("tabs-css");
		return;
	}

	await loadCSS("css/tabs.css", "tabs-css");

	try {
		const tabs = await chrome.tabs.query({});
		ribbon = createTabsRibbon(tabs);
		document.body.appendChild(ribbon);
		attachTabsListeners();
		if (_tabsToggleElement) {
			_tabsToggleElement.classList.add("active");
			try {
				_tabsToggleElement.setAttribute("aria-expanded", "true");
			} catch (e) {}
		}

		_scheduleTabsRibbonAutoClose();
	} catch (e) {
		// console.error('Failed to show tabs ribbon', e);
	}
}

function createTabsRibbon(tabs) {
	const MAX_TABS_PER_WINDOW = 4;
	const BASE_MAX_TABS = 7; // Base max at full screen width (1920px reference)

	// Calculate dynamic max tabs based on viewport width vs screen width
	// At full screen (ratio = 1.0) -> 8 tabs
	// At half screen (ratio = 0.5) -> 4 tabs
	const screenWidth = window.screen.width || 1920;
	const viewportWidth = window.innerWidth || screenWidth;
	const ratio = Math.min(viewportWidth / screenWidth, 1.0); // Cap at 1.0
	const MAX_TOTAL_TABS = Math.max(2, Math.floor(BASE_MAX_TABS * ratio)); // Minimum 2 tabs

	const grouped = {};
	tabs.forEach((t) => {
		if (!grouped[t.windowId]) grouped[t.windowId] = [];
		grouped[t.windowId].push(t);
	});

	const ribbon = document.createElement("div");
	ribbon.id = "tabs-ribbon";

	const content = document.createElement("div");
	content.className = "tabs-ribbon-content";

	const windowIds = Object.keys(grouped);
	let totalTabsShown = 0;
	let hiddenWindowsCount = 0;
	let totalHiddenTabs = 0;

	let mergeBtn = null;
	if (windowIds.length > 1) {
		const wrapper = document.createElement("div");
		wrapper.className = "control-wrapper";

		mergeBtn = document.createElement("div");
		mergeBtn.className = "btn btn-icon merge-windows-btn action-item";
		const mergeIcon = document.createElement("span");
		mergeIcon.className = "merge-windows-icon";
		mergeIcon.setAttribute("aria-hidden", "true");
		renderInlineIcon(
			mergeIcon,
			"assets/svgs-fontawesome/solid/object-group.svg",
		);
		mergeBtn.appendChild(mergeIcon);
		mergeBtn.title = "Merge all windows into first window";
		mergeBtn.addEventListener("click", async () => {
			try {
				await mergeAllToFirstWindow(windowIds);
				await refreshTabsRibbon();
			} catch (e) {
				// console.error('Failed to merge windows', e);
			}
		});
		wrapper.appendChild(mergeBtn);
		mergeBtn = wrapper;
	}

	for (const [windowId, windowTabs] of Object.entries(grouped)) {
		// Check if we've hit global limit
		if (totalTabsShown >= MAX_TOTAL_TABS) {
			hiddenWindowsCount++;
			totalHiddenTabs += windowTabs.length;
			continue;
		}

		const group = document.createElement("div");
		group.className = "window-group";
		group.dataset.windowId = windowId;

		const windowPill = document.createElement("div");
		windowPill.className = "btn btn-icon window-selector";
		windowPill.title = `Window (${windowTabs.length} tabs)`;
		const winIcon = document.createElement("span");
		winIcon.className = "window-selector-icon";
		winIcon.setAttribute("aria-hidden", "true");
		renderInlineIcon(
			winIcon,
			"assets/svgs-fontawesome/solid/window-maximize.svg",
		);
		windowPill.appendChild(winIcon);

		windowPill.addEventListener("click", async () => {
			try {
				const activeTabs = await chrome.tabs.query({
					windowId: parseInt(windowId),
					active: true,
				});
				const active = activeTabs && activeTabs[0];
				if (active) {
					try {
						if (chrome.windows && chrome.windows.update) {
							await chrome.windows.update(parseInt(windowId), {
								focused: true,
							});
						}
						await chrome.tabs.update(active.id, { active: true });
					} catch (err) {
						const tabEl = content.querySelector(
							`.tab-item[data-tab-id='${active.id}']`,
						);
						if (tabEl) {
							tabEl.click();
							return;
						}
						if (active.url)
							await chrome.tabs.create({ url: active.url });
					}
				} else {
					if (windowTabs && windowTabs[0]) {
						const firstId = windowTabs[0].id;
						document
							.querySelectorAll("#tabs-ribbon .tab-item.active")
							.forEach((el) => el.classList.remove("active"));
						const firstEl = content.querySelector(
							`.tab-item[data-tab-id='${firstId}']`,
						);
						if (firstEl) firstEl.classList.add("active");
					}
				}
			} catch (e) {
				// console.error('Select window pill failed', e);
			}
		});

		group.appendChild(windowPill);

		const list = document.createElement("div");
		list.className = "tabs-ribbon-list";

		// Calculate how many tabs to show from this window
		const remainingSlots = MAX_TOTAL_TABS - totalTabsShown;
		const tabsToShowCount = Math.min(
			windowTabs.length,
			MAX_TABS_PER_WINDOW,
			remainingSlots,
		);
		const hiddenInWindowCount = windowTabs.length - tabsToShowCount;

		for (let i = 0; i < tabsToShowCount; i++) {
			const tab = windowTabs[i];
			const item = document.createElement("div");
			item.className = "btn btn-icon-text tab-item";
			if (tab.active) item.classList.add("active");
			item.dataset.tabId = tab.id;
			item.dataset.windowId = tab.windowId;

			const icon = document.createElement("span");
			icon.className = ""; // No specific class needed, base.css handles spans in btns
			icon.setAttribute("aria-hidden", "true");
			renderBrandIcon(icon, tab.url);

			const title = document.createElement("span");
			title.className = "text";
			title.textContent = tab.title || tab.url || "Untitled";

			item.appendChild(icon);
			item.appendChild(title);

			item.addEventListener("click", async () => {
				const tabId = parseInt(item.dataset.tabId);
				const wId = parseInt(item.dataset.windowId);
				try {
					await chrome.windows.update(wId, { focused: true });
					await chrome.tabs.update(tabId, { active: true });
					updateActiveTabVisual(tabId);
					const r = document.getElementById("tabs-ribbon");
					if (r) document.body.removeChild(r);
					detachTabsListeners();
				} catch (e) {
					// console.error('Failed to switch to tab', e);
				}
			});

			list.appendChild(item);
			totalTabsShown++;
		}

		// Add counter for hidden tabs in this window
		if (hiddenInWindowCount > 0) {
			const counter = document.createElement("div");
			counter.className = "btn btn-icon tab-counter";
			counter.textContent = `+${hiddenInWindowCount}`;
			counter.title = `${hiddenInWindowCount} more tabs in this window`;
			counter.addEventListener("click", async () => {
				// Focus this window when clicking counter
				try {
					if (chrome.windows && chrome.windows.update) {
						await chrome.windows.update(parseInt(windowId), {
							focused: true,
						});
					}
				} catch (e) {}
			});
			list.appendChild(counter);
			totalHiddenTabs += hiddenInWindowCount;
		}

		group.appendChild(list);
		content.appendChild(group);
	}

	// Add overflow indicator for hidden windows
	if (hiddenWindowsCount > 0) {
		const wrapper = document.createElement("div");
		wrapper.className = "control-wrapper";

		const overflowIndicator = document.createElement("div");
		overflowIndicator.className =
			"btn btn-icon btn-display overflow-indicator";
		overflowIndicator.textContent = `+${hiddenWindowsCount}`;
		overflowIndicator.title = `${hiddenWindowsCount} more window${
			hiddenWindowsCount > 1 ? "s are" : " is"
		} open with ${totalHiddenTabs} tab${
			totalHiddenTabs > 1 ? "s" : ""
		} combined`;

		wrapper.appendChild(overflowIndicator);
		content.appendChild(wrapper);
	}

	if (mergeBtn) content.appendChild(mergeBtn);

	content.addEventListener("mouseenter", () => {
		_clearTabsRibbonAutoCloseTimer();
	});
	content.addEventListener("mouseleave", () => {
		_scheduleTabsRibbonAutoClose();
	});

	ribbon.appendChild(content);
	return ribbon;
}

async function refreshTabsRibbon() {
	const ribbon = document.getElementById("tabs-ribbon");
	if (!ribbon) return;
	try {
		_clearTabsRibbonAutoCloseTimer();
		const tabs = await chrome.tabs.query({});
		const newRibbon = createTabsRibbon(tabs);
		ribbon.replaceWith(newRibbon);
	} catch (e) {
		// console.error('Failed to refresh tabs ribbon', e);
	}
}

async function mergeAllToFirstWindow(windowIds) {
	if (!windowIds || windowIds.length < 2) return;
	const targetWindowId = parseInt(windowIds[0]);

	const allTabs = await chrome.tabs.query({});
	const tabsToMove = allTabs
		.filter((t) => t.windowId !== targetWindowId)
		.map((t) => t.id);

	for (const tabId of tabsToMove) {
		try {
			await chrome.tabs.move(tabId, {
				windowId: targetWindowId,
				index: -1,
			});
		} catch (e) {
			// console.warn('Could not move tab', tabId, e);
			try {
				const tab = allTabs.find((t) => t.id === tabId);
				if (tab && tab.url) {
					await chrome.tabs.create({
						windowId: targetWindowId,
						url: tab.url,
					});
					await chrome.tabs.remove(tabId);
				}
			} catch (inner) {
				// console.error('Fallback move failed for tab', tabId, inner);
			}
		}
	}
}

function updateActiveTabVisual(activeTabId) {
	document
		.querySelectorAll("#tabs-ribbon .tab-item.active")
		.forEach((el) => el.classList.remove("active"));
	const el = document.querySelector(
		`#tabs-ribbon .tab-item[data-tab-id='${activeTabId}']`,
	);
	if (el) el.classList.add("active");
}

function _scheduleTabsRibbonAutoClose() {
	_clearTabsRibbonAutoCloseTimer();
	_tabsRibbonAutoCloseTimer = setTimeout(() => {
		const ribbon = document.getElementById("tabs-ribbon");
		if (ribbon) {
			try {
				document.body.removeChild(ribbon);
			} catch (e) {}
			detachTabsListeners();
			if (_tabsToggleElement) {
				_tabsToggleElement.classList.remove("active");
				try {
					_tabsToggleElement.setAttribute("aria-expanded", "false");
				} catch (e) {}
			}
			unloadCSS("tabs-css");
		}
	}, TABS_RIBBON_AUTO_CLOSE_MS);
}

function _clearTabsRibbonAutoCloseTimer() {
	if (_tabsRibbonAutoCloseTimer) {
		clearTimeout(_tabsRibbonAutoCloseTimer);
		_tabsRibbonAutoCloseTimer = null;
	}
}

let _tabChangeTimeout = null;
let _resizeTimeout = null;

function onTabChange() {
	if (_tabChangeTimeout) clearTimeout(_tabChangeTimeout);
	_tabChangeTimeout = setTimeout(() => {
		refreshTabsRibbon();
		_tabChangeTimeout = null;
	}, 200);
}

function onWindowResize() {
	// Debounce resize events
	if (_resizeTimeout) clearTimeout(_resizeTimeout);
	_resizeTimeout = setTimeout(() => {
		refreshTabsRibbon();
		_resizeTimeout = null;
	}, 200);
}

function attachTabsListeners() {
	if (_tabsRibbonListeners) return;
	function onKeyDown(ev) {
		if (ev.key === "Escape") {
			const ribbon = document.getElementById("tabs-ribbon");
			if (ribbon) {
				try {
					document.body.removeChild(ribbon);
				} catch (e) {}
				detachTabsListeners();
				if (_tabsToggleElement) {
					_tabsToggleElement.classList.remove("active");
					try {
						_tabsToggleElement.setAttribute(
							"aria-expanded",
							"false",
						);
					} catch (e) {}
				}
				unloadCSS("tabs-css");
			}
		}
	}
	document.addEventListener("keydown", onKeyDown);

	// Tab Events
	chrome.tabs.onCreated.addListener(onTabChange);
	chrome.tabs.onUpdated.addListener(onTabChange);
	chrome.tabs.onRemoved.addListener(onTabChange);
	chrome.tabs.onMoved.addListener(onTabChange);
	chrome.tabs.onDetached.addListener(onTabChange);
	chrome.tabs.onAttached.addListener(onTabChange);

	// Window resize event for dynamic tab count
	window.addEventListener("resize", onWindowResize);

	_tabsRibbonListeners = { onKeyDown, onTabChange, onWindowResize };
}

function detachTabsListeners() {
	if (!_tabsRibbonListeners) return;
	document.removeEventListener("keydown", _tabsRibbonListeners.onKeyDown);

	chrome.tabs.onCreated.removeListener(_tabsRibbonListeners.onTabChange);
	chrome.tabs.onUpdated.removeListener(_tabsRibbonListeners.onTabChange);
	chrome.tabs.onRemoved.removeListener(_tabsRibbonListeners.onTabChange);
	chrome.tabs.onMoved.removeListener(_tabsRibbonListeners.onTabChange);
	chrome.tabs.onDetached.removeListener(_tabsRibbonListeners.onTabChange);
	chrome.tabs.onAttached.removeListener(_tabsRibbonListeners.onTabChange);

	// Remove resize listener
	window.removeEventListener("resize", _tabsRibbonListeners.onWindowResize);

	if (_tabChangeTimeout) {
		clearTimeout(_tabChangeTimeout);
		_tabChangeTimeout = null;
	}
	if (_resizeTimeout) {
		clearTimeout(_resizeTimeout);
		_resizeTimeout = null;
	}

	_tabsRibbonListeners = null;
}
